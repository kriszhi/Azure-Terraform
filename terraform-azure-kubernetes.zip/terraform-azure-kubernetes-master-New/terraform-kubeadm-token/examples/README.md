# Examples

This examples shows how to include this module. To run this example, execute:
```
$ terraform init
$ terraform apply
```